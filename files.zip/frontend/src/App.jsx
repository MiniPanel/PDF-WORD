import React, { useState, useRef } from "react";
import styled, { createGlobalStyle } from "styled-components";
import { FiUploadCloud } from "react-icons/fi";

const API_URL = process.env.REACT_APP_API_URL || "/api/convert"; // for dev/prod flexibility

const GlobalStyle = createGlobalStyle`
  body {
    font-family: 'Inter', sans-serif;
    background: linear-gradient(120deg, #a18cd1, #fbc2eb 100%);
    min-height: 100vh;
    margin: 0;
    padding: 0;
  }
`;

const Container = styled.div`
  max-width: 400px;
  margin: 60px auto;
  background: #fff;
  border-radius: 18px;
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.18);
  padding: 2.5rem 2rem 2rem 2rem;
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const Title = styled.h1`
  margin-bottom: 0.7em;
  font-weight: 800;
  background: linear-gradient(90deg, #7f53ac, #647dee);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  font-size: 2rem;
`;

const DragDrop = styled.label`
  width: 100%;
  min-height: 140px;
  border: 2px dashed #a18cd1;
  border-radius: 12px;
  background: #faf8ff;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  cursor: pointer;
  margin-bottom: 1.2em;
  transition: border-color 0.2s;

  &:hover {
    border-color: #7f53ac;
  }
`;

const FileInput = styled.input`
  display: none;
`;

const UploadIcon = styled(FiUploadCloud)`
  color: #a18cd1;
  font-size: 2.5rem;
  margin-bottom: 0.4em;
`;

const FileName = styled.p`
  color: #333;
  font-size: 1rem;
  margin-bottom: 0.7em;
`;

const Button = styled.button`
  background: linear-gradient(90deg, #a18cd1, #fbc2eb);
  color: #fff;
  font-weight: bold;
  border: none;
  border-radius: 8px;
  padding: 0.8em 2.2em;
  font-size: 1.1rem;
  cursor: pointer;
  margin-top: 1em;
  box-shadow: 0 2px 8px rgba(161,140,209,0.08);
  transition: background 0.2s;
  &:hover {
    background: linear-gradient(90deg, #7f53ac, #647dee);
  }
  &:disabled {
    background: #d3cce3;
    cursor: not-allowed;
  }
`;

const Loader = styled.div`
  margin-top: 1em;
  border: 3px solid #f3f3f3;
  border-radius: 50%;
  border-top: 3px solid #a18cd1;
  width: 36px;
  height: 36px;
  animation: spin 1s linear infinite;
  @keyframes spin { 100% { transform: rotate(360deg); } }
`;

const DownloadLink = styled.a`
  display: block;
  margin-top: 1.7em;
  color: #7f53ac;
  font-weight: 600;
  text-decoration: underline;
  font-size: 1.1em;
`;

const ErrorMsg = styled.div`
  color: #e74c3c;
  margin-top: 1em;
  font-size: 1em;
`;

export default function App() {
  const [file, setFile] = useState(null);
  const [converting, setConverting] = useState(false);
  const [wordUrl, setWordUrl] = useState(null);
  const [error, setError] = useState("");
  const fileInputRef = useRef();

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setWordUrl(null);
      setError("");
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
      setWordUrl(null);
      setError("");
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleConvert = async () => {
    setConverting(true);
    setWordUrl(null);
    setError("");

    const data = new FormData();
    data.append("file", file);

    try {
      const response = await fetch(API_URL, {
        method: "POST",
        body: data,
      });

      if (!response.ok) {
        const err = await response.json();
        setError(err.error || "Failed to convert file.");
        setConverting(false);
        return;
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      setWordUrl(url);
    } catch (e) {
      setError("Conversion failed. Try again.");
    }
    setConverting(false);
  };

  return (
    <>
      <GlobalStyle />
      <Container>
        <Title>PDF to Word</Title>
        <DragDrop
          htmlFor="file-upload"
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onClick={() => fileInputRef.current && fileInputRef.current.click()}
        >
          <UploadIcon />
          <div>
            <div style={{ marginBottom: "0.4em", fontWeight: "600", color: "#7f53ac" }}>
              Drag & drop a PDF here
            </div>
            <div style={{ fontSize: "0.95em", color: "#888" }}>
              or click to select
            </div>
          </div>
          <FileInput
            id="file-upload"
            ref={fileInputRef}
            type="file"
            accept="application/pdf"
            onChange={handleFileChange}
          />
        </DragDrop>

        {file && <FileName>{file.name}</FileName>}

        <Button
          disabled={!file || converting}
          onClick={handleConvert}
        >
          {converting ? "Converting..." : "Convert to Word"}
        </Button>

        {converting && <Loader />}

        {wordUrl && (
          <DownloadLink href={wordUrl} download="converted.docx">
            Download Word File
          </DownloadLink>
        )}

        {error && <ErrorMsg>{error}</ErrorMsg>}
      </Container>
    </>
  );
}